### Additional information

Please cite the original article as:

The pre-print of the article can be found at:

The OSF project page, with data and analysis scripts can be found at::

The code for this app can be downloaded at: