#-----------------------
#ERCEL R minikurz
#
#Data processing using the Tidyverse
#-----------------------

#this line of code is important and sets the working directory
#(which is the folder that contains all the files required for your code to work)
#please make sure you run this line of code first
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
